import { Component, OnInit } from '@angular/core';
import { Movie } from '../movie';
import { MovieService } from "../movie.service";

@Component({
  selector: 'app-add-movie',
  templateUrl: './add-movie.component.html',
  styleUrls: ['./add-movie.component.css']
})
export class AddMovieComponent implements OnInit {

  movieList : any = [];
  movie:Movie=new Movie();

  constructor(private movieService: MovieService) {
    this.movieService.getMovieDetails().subscribe(data => this.movieList = data);
   }

  ngOnInit() {
  }
  genre:string[]=["Auto-Biography","Biography","Sci-Fi","Horror","Drama","Novel"];

  insert(data){
    alert(`Movie Name: ${data.name} Rating: ${data.rating} Genre: ${data.genre}`);
    
    this.movie.name=data.name;
    this.movie.rating=data.rating;
    this.movie.genre=data.genre;
    console.log(this.movie);
    this.movieService.setMovieDetails(this.movie);
  }
}
