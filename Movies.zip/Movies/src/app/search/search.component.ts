import { Component, OnInit } from '@angular/core';
import { MovieService } from '../movie.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
movieList:any[]
  constructor(private movieService: MovieService) {
    this.movieList= this.movieService.movieList;
   }

  ngOnInit() {
  }

  movieList2:any=[];
  genre: string[] = ["Auto-Biography","Biography","Sci-Fi","Horror","Drama","Novel"];
  search(data){
    this.movieList2 = this.movieService.search(data);
  }

}
